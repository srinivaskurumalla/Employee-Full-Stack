package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.exception.EmployeeAlreadyExistsException;
import com.employee.exception.EmployeeNotFoundException;
import com.employee.model.EmpSignUp;
import com.employee.model.Employee;
import com.employee.service.IEmployeeService;
import com.employee.service.ISignUpService;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:4200")

public class EmpController {

	@Autowired
	private IEmployeeService empService;
	
	@Autowired
	private ISignUpService signUpService;
	
	@PostMapping("/signup")
	public ResponseEntity<EmpSignUp> signUpToDB(@RequestBody EmpSignUp empSignUp)
	{
		try
		{
			EmpSignUp saveEmpSignUp = this.signUpService.saveEmpSignUp(empSignUp);
			return new ResponseEntity<>(saveEmpSignUp, HttpStatus.CREATED);
		}
		catch(EmployeeAlreadyExistsException e)
		{
			return new ResponseEntity<EmpSignUp>(HttpStatus.CONFLICT);
		}

	}
	
	@GetMapping("/signup")
	public ResponseEntity<?> getAllSignUps()
	{
		try
		{
			List allSignUps = this.signUpService.getAllSignUps();
			return new ResponseEntity<>(allSignUps, HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>("Error While getting all the Employees Data", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
//	@GetMapping("/login")
//	public ResponseEntity<EmpSignUp> login(@RequestBody EmpSignUp empSignUp) throws EmployeeNotFoundException {
//
//		try {
//			EmpSignUp signedEmployee = this.signUpService.getSignedEmployee(empSignUp);
//			return new ResponseEntity<>(signedEmployee,HttpStatus.OK);
//			}
//		catch(EmployeeNotFoundException e){
//			return new ResponseEntity<EmpSignUp>(HttpStatus.BAD_GATEWAY);
//		}
//       // return signUpService.getSignedEmployee(empSignUp);
//    }
	
	@PostMapping("/saveEmployee")
	public ResponseEntity<Employee> saveEmpToDB(@RequestBody Employee employee)
	{
		try
		{
			Employee savedEmployee = this.empService.saveEmployee(employee);
			return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
		}
		catch(Exception e)
		{
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping("/getEmployee/{empId}")
	public ResponseEntity<?> getStdByIdFromDB(@PathVariable("empId") Long ID)
	{
		try
		{
			Employee getEmployee = this.empService.getEmployee(ID);
			return new ResponseEntity<>(getEmployee, HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>("Employee Not Found with id :"+ID,HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/getAllEmployees")
	public ResponseEntity<?> getAllEmpFromDB()
	{
		try
		{
			List allEmployees = this.empService.getAllEmployees();
			return new ResponseEntity<>(allEmployees, HttpStatus.OK);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>("Error While getting all the Employees Data", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	@DeleteMapping("/deleteEmployeeById/{Id}")
	public ResponseEntity<?> deleteEmpById(@PathVariable("Id") long empId)
	{
		//boolean status = false;
		try
		{

			boolean status = this.empService.deleteEmployee(empId);
			if(status)
			{
				return new ResponseEntity<>(status, HttpStatus.OK);
			}
			else
			{
				//return new ResponseEntity<>("error While deleting the id"+Id, HttpStatus.INTERNAL_SERVER_ERROR);
				return null;
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>("error While deleting the id"+empId, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}


	@PutMapping("/updateEmployee/{Id}")

	public ResponseEntity<?> updateEmployeeByIdToDB(@PathVariable("Id") long empId,@RequestBody Employee employee)
	{

		try
		{
			Employee updateEmployeeById = this.empService.updateEmployeeById(empId, employee);
			return new ResponseEntity<>(updateEmployeeById, HttpStatus.CREATED);
		}
		catch(Exception e)
		{
			return new ResponseEntity<>("Error While updating data", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}






