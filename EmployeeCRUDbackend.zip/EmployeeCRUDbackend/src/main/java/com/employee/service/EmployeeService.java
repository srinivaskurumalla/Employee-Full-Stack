package com.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.model.Employee;
import com.employee.repository.EmployeeRepository;

@Service
public class EmployeeService implements IEmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee saveEmployee(Employee employee) throws Exception {
		Optional<Employee> employeeExist = this.employeeRepository.findById(employee.getId());
		if(employeeExist.isPresent())
		{
			throw new Exception();
		}
		else
		{
			return this.employeeRepository.save(employee);
		}
		
	}

	@Override
	public boolean deleteEmployee(long id) throws Exception {
		Optional<Employee> employeeExist = this.employeeRepository.findById(id);
		boolean status = false;
		if(employeeExist.isPresent())
		{
			employeeRepository.delete(employeeExist.get());
			status =  true;
		}
		else
		{
			throw new Exception();
						
		}
		return status;
		
		
	}

	@Override
	public Employee getEmployee(long id) throws Exception {
		Optional<Employee> employeeExist = this.employeeRepository.findById(id);
		if(employeeExist.isPresent())
		{
			return employeeExist.get();
		}
		else
		{
			throw new Exception();
		}
		
	}

	@Override
	public List getAllEmployees() {
		
		return employeeRepository.findAll();
	}

	

	@Override
	public Employee updateEmployeeById(long id, Employee employee) throws Exception {
		Optional<Employee> employeeExist = this.employeeRepository.findById(id);
		
		Employee empObj = null;
		Employee newEmpObj = null;
		
		if(employeeExist.isPresent())
		{
			empObj = employeeExist.get();
			
			empObj.setId(employee.getId());
			empObj.setFirstName(employee.getFirstName());
			empObj.setLastName(employee.getLastName());
			empObj.setEmail(employee.getEmail());
			empObj.setPhone(employee.getPhone());
			empObj.setSalary(employee.getSalary());
			
			newEmpObj = this.employeeRepository.save(empObj);
			
			return newEmpObj;
			
		}
		else
		{
			throw new Exception();
		}
	}
}
