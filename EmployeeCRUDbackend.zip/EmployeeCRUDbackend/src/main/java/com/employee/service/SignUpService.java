package com.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.exception.EmployeeAlreadyExistsException;
import com.employee.exception.EmployeeNotFoundException;
import com.employee.model.EmpSignUp;
import com.employee.repository.SignUpRepository;
@Service
public class SignUpService implements ISignUpService{

	@Autowired
	private SignUpRepository signUpRepository;
	
	@Override
	public EmpSignUp saveEmpSignUp(EmpSignUp empSignUp) throws EmployeeAlreadyExistsException {
		Optional<EmpSignUp> empExists = this.signUpRepository.findById(empSignUp.getId());
		
		if(empExists.isPresent()) {
			throw new EmployeeAlreadyExistsException();
		}
		else {
			return this.signUpRepository.save(empSignUp);
		}
	}

	@Override
	public EmpSignUp getSignedEmployee(EmpSignUp empSignUp) throws EmployeeNotFoundException {
		EmpSignUp empExists = this.signUpRepository.findById(empSignUp.getId()).orElse(null);
		
		
			if(empSignUp.getEmail().equals(empExists.getEmail()) && 
					empSignUp.getPassword().equals(empExists.getPassword())){
			
				return empExists;
			}
			else
			{
				throw new EmployeeNotFoundException();
			}
		
	}

	@Override
	public List getAllSignUps() {
		return signUpRepository.findAll();
	}
	
	

}
