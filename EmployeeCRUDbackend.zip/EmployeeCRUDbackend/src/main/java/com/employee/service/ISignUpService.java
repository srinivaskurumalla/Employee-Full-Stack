package com.employee.service;

import java.util.List;

import com.employee.exception.EmployeeAlreadyExistsException;
import com.employee.exception.EmployeeNotFoundException;
import com.employee.model.EmpSignUp;

public interface ISignUpService {

	EmpSignUp saveEmpSignUp(EmpSignUp empSignUp) throws EmployeeAlreadyExistsException;
	EmpSignUp getSignedEmployee(EmpSignUp empSignUp) throws EmployeeNotFoundException;
	List getAllSignUps();
}
