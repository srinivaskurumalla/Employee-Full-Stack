package com.employee.service;

import java.util.List;

import com.employee.model.Employee;

public interface IEmployeeService {

	Employee saveEmployee(Employee employee) throws Exception;
	boolean deleteEmployee(long id) throws Exception;
	Employee getEmployee(long id) throws Exception;
	Employee updateEmployeeById(long id,Employee employee) throws Exception;
	List getAllEmployees();
}
