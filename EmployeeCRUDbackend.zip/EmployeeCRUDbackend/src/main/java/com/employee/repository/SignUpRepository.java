package com.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.model.EmpSignUp;

public interface SignUpRepository extends JpaRepository<EmpSignUp, Long>{

}
